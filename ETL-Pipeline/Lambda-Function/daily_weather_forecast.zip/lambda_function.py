import json

def lambda_handler(event, context):


    import pandas as pd
    import requests
    import marcus_keys
    
    
    def get_current_weather_data(city_list):
        all_hourly_data = []
        all_daily_data = []
    
        for city_name in city_list:
            latitude = cities_data_df[cities_data_df['city_name'] == city_name]['latitude'].values[0]
            longitude = cities_data_df[cities_data_df['city_name'] == city_name]['longitude'].values[0]
    
            url = "https://api.open-meteo.com/v1/forecast"
            params = {
                "latitude": latitude,
                "longitude": longitude,
                "models": "best_match",
                "forecast_days": 1,
                "daily": "weathercode,temperature_2m_max,temperature_2m_min,temperature_2m_mean,precipitation_sum,rain_sum,snowfall_sum,windspeed_10m_max,shortwave_radiation_sum",
                "hourly": "temperature_2m,relativehumidity_2m,precipitation,rain,snowfall,weathercode,surface_pressure,cloudcover,visibility,evapotranspiration,windspeed_10m,winddirection_10m",
                "timezone": "Europe/Berlin"
            }
    
            response = requests.get(url, params=params)
            current_data = response.json()
    
            current_hourly_data = current_data['hourly']
            current_daily_data = current_data['daily']
    
            current_hourly_df = pd.DataFrame(current_hourly_data)
            current_daily_df = pd.DataFrame(current_daily_data)
    
            current_hourly_df['city_name'] = city_name
            current_daily_df['city_name'] = city_name
    
            all_hourly_data.append(current_hourly_df)
            all_daily_data.append(current_daily_df)
    
        all_hourly_data = pd.concat(all_hourly_data, ignore_index=True)
        all_daily_data = pd.concat(all_daily_data, ignore_index=True)
    
        return all_hourly_data, all_daily_data
    
    
    url = "https://drive.google.com/file/d/1TdhZIuhQfKVSHSnQK2Epst8ktkdo14DY/view?usp=sharing"
    path = 'https://drive.google.com/uc?export=download&id='+url.split('/')[-2]
    worldcities_df = pd.read_csv(path)
    
    city_list = [
        "Toronto", "Mexico City", "São Paulo", "Buenos Aires", "Rio de Janeiro",
        "Bogotá", "Lima", "London", "Paris", "Berlin", "Rome", "Madrid", "Sydney", "Melbourne", "Brisbane", "Perth", "Adelaide",
        "Cairo", "Lagos", "Johannesburg", "Nairobi", "Casablanca", "Addis Ababa", "Dakar", "Accra", "Cape Town","Tokyo", "Mumbai", "Beijing", "Istanbul", "Bangkok", "Seoul", "Jakarta", "Karachi", "Riyadh", "Manila"
    ]
    
    columns_to_remove = ['city_ascii', 'iso2', 'iso3', 'admin_name', 'capital', 'id']
    cities_data_df = worldcities_df.drop(columns=columns_to_remove)
    
    column_mapping = {
        'city': 'city_name',
        'lat': 'latitude',
        'lng': 'longitude'
    }
    
    cities_data_df.rename(columns=column_mapping, inplace=True)
    
    hourly_data, daily_data = get_current_weather_data(city_list)
    
    column_mapping_hrl = {
        'city': 'city_name',
        'time': 'date_time',
        'weathercode': 'weather_code',
        'temperature_2m': 'temperature',
        'windspeed_10m': 'wind_speed',
        'winddirection_10m': 'wind_direction',
        'relativehumidity_2m': 'humidity'
    }
    
    hourly_data.rename(columns=column_mapping_hrl, inplace=True)
    current_hourly_df = hourly_data
    current_hourly_df["date_time"] = pd.to_datetime(current_hourly_df["date_time"])
    
    column_mapping_dl = {
        'weathercode': 'weather_code',
        'city': 'city_name',
        'temperature_2m_max': 'temperature_max',
        'temperature_2m_min': 'temperature_min',
        'temperature_2m_mean': 'temperature_avg',
        'precipitation_sum': 'precipitation',
        'windspeed_10m_max': 'wind_speed',
        'rain_sum': 'rain',
        'snowfall_sum': 'snowfall',
        'shortwave_radiation_sum': 'shortwave_radiation',
        'time': 'date_time'
    }
    
    daily_data.rename(columns=column_mapping_dl, inplace=True)
    current_daily_df = daily_data
    current_daily_df["date_time"] = pd.to_datetime(current_daily_df["date_time"])
    
    
    schema="jam_fp_db"
    host="jam-project-2023-db.cjdcbdhnueky.eu-north-1.rds.amazonaws.com"
    user="mkadmin"
    password=marcus_keys.aws_rds_key
    port=3306
    con = f'mysql+pymysql://{user}:{password}@{host}:{port}/{schema}'
    
    current_daily_df.to_sql('current_weather_daily',
                            if_exists='replace',
                            con=con,
                            index=False)
    
    current_hourly_df.to_sql('current_weather_hourly',
                            if_exists='replace',
                            con=con,
                            index=False)
                        
                        
    return {
        'statusCode': 200,
        'body': json.dumps('Lambda Function ran successfully!')
    }
